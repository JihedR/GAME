#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>
#include "header.h"

int main(int argc,char**argv){
//init tout
SDL_Init(SDL_INIT_EVERYTHING);
int volume=20000;
int volumemu=20000;
if (Mix_OpenAudio(volume,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024)==-1){printf("%s",Mix_GetError());}
//declaration des variables
image background1,background2,play,play1,cont,cont1,settings,settings1,quit,quit1,emblem,playinter,settinginter,save,save1,cancel,cancel1,checkfull,checkhemo,vol,volmax,volmin,volmu,volmaxmu,volminmu;
image background1f, background2f, playf , play1f , contf, cont1f, settingsf , settings1f, quitf, quit1f, playinterf, settinginterf, savef, save1f, cancelf, cancel1f, checkfullf, checkhemof, volf, volmaxf, volminf,volmuf,volmaxmuf,volminmuf;
Mix_Music *music;
Mix_Chunk *sonmotion;
Mix_Chunk *sonclick;
SDL_Event ev;
//creation fenetre
SDL_Surface *screen = SDL_SetVideoMode(1027,599,32,SDL_SWSURFACE| SDL_RESIZABLE);
if (!screen){
	printf("Unable to set video\n");
	return 1;
}


//Init des variables
printf("initalizing...");
initimage(&volmax,479,207,0,0,89,15,"volume100.png");
initimage(&vol,479,207,0,0,89,15,"volume50.png");
initimage(&volmin,479,207,0,0,89,15,"volume0.png");
initimage(&volmaxmu,479,242,0,0,89,15,"volume100.png");
initimage(&volmu,479,242,0,0,89,15,"volume50.png");
initimage(&volminmu,479,242,0,0,89,15,"volume0.png");
initimage(&checkfull,670,208,0,0,10,10,"check.png");
initimage(&checkhemo,418,336,0,0,10,10,"check.png");
initimage(&background1,0,0,0,0,1027,599,"BACKGROUND1.png");
initimage(&background2,0,0,0,0,1027,599,"BACKGROUND2.png");
initimage(&play,83,270,0,0,88,53,"PLAY.png");
initimage(&play1,83,270,0,0,88,53,"PLAYSELEC.png");
initimage(&cont,51,346,0,0,159,53,"CONTINUE.png");
initimage(&cont1,51,346,0,0,159,53,"CONTINUESELEC.png");
initimage(&settings,55,435,0,0,139,53,"SETTINGS.png");
initimage(&settings1,55,435,0,0,139,53,"SETTINGSSELEC.png");
initimage(&quit,81,519,0,0,86,53,"QUIT.png");
initimage(&quit1,81,519,0,0,86,53,"QUITSELEC.png");
initimage(&emblem,904,8,0,0,115,100,"emblem.png");
initimage(&save1,730,390,0,0,84,41,"SAVESELEC.png");
initimage(&save,730,390,0,0,84,41,"save.png");
initimage(&cancel,440,390,0,0,105,40,"cancel.png");
initimage(&cancel1,440,390,0,0,105,40,"CANCELSELEC.png");
initimage(&playinter,300,150,0,0,678,323,"PLAYINTER.png");
initimage(&settinginter,390,110,0,0,478,350,"SETTINGINTER.png");
//init des variables fullscreen
initimage(&volmaxf,900,365,0,0,164,25,"volume100f.png");
initimage(&volf,900,365,0,0,164,25,"volume50f.png");
initimage(&volminf,900,365,0,0,164,25,"volume0f.png");
initimage(&volmaxmuf,900,430,0,0,164,25,"volume100f.png");
initimage(&volmuf,900,430,0,0,164,25,"volume50f.png");
initimage(&volminmuf,900,430,0,0,164,25,"volume0f.png");
initimage(&checkfullf,1255,365,0,0,18,19,"checkf.png");
initimage(&checkhemof,785,590,0,0,18,19,"checkf.png");
initimage(&background1f,0,0,0,0,1924,1083,"background1f.png");
initimage(&background2f,0,0,0,0,1925,1082,"background2f.png");
initimage(&playf,150,500,0,0,165,96,"playf.png");
initimage(&play1f,150,500,0,0,165,96,"playselecf.png");
initimage(&contf,95,630,0,0,298,95,"continuef.png");
initimage(&cont1f,95,630,0,0,298,95,"continueselecf.png");
initimage(&settingsf,55,435,0,0,139,53,"settingsf.png");
initimage(&settings1f,55,435,0,0,139,53,"settingsselecf.png");
initimage(&quitf,81,519,0,0,86,53,"quitf.png");
initimage(&quit1f,81,519,0,0,86,53,"quitselecf.png");
initimage(&save1f,730,390,0,0,84,41,"saveselecf.png");
initimage(&savef,730,390,0,0,84,41,"savef.png");
initimage(&cancelf,440,390,0,0,105,40,"cancelf.png");
initimage(&cancel1f,440,390,0,0,105,40,"cancelselecf.png");

//load music	
music=Mix_LoadMUS("music.mp3");
sonclick=Mix_LoadWAV("click.wav");
sonmotion=Mix_LoadWAV("button.wav");
//init des entiers
int etat_play=0;
int etat_continue=0;
int etat_settings=0;
int etat_quit=0;
int played=0;
int played1=0;
int played2=0;
int played3=0;
int played4=0;
int played5=0;
int checkf=0;
int checkh=0;
int volu=2;
int volum=2;
int mouseX;
int mouseY;
int channel;
Mix_PlayMusic(music,-1);
//Game loop
int run=1;
while(run){
	//Display
	if(etat_play==1 && checkf==0){afficher(background2,screen);afficher(playinter,screen);}
	if(etat_settings==1){
		afficher(background2,screen);
		afficher(settinginter,screen);
		afficher(cancel,screen);
		afficher(save,screen);
		if(played4==0){afficher(save,screen);}
		else{afficher(save1,screen);}
		if(played5==0){afficher(cancel,screen);}
		else{afficher(cancel1,screen);}
		if(checkf==1)
			{afficher(checkfull,screen);
			}
		if(checkh==1){afficher(checkhemo,screen);}
		if(volu==0){afficher(volmin,screen);volume=0;Mix_Volume(channel, volume);}
		else if(volu==1){afficher(vol,screen);volume=10000;Mix_Volume(channel, volume);}
		else if(volu==2){afficher(volmax,screen);volume=20000;Mix_Volume(channel, volume);}
			}
		if(volum==0){afficher(volminmu,screen);volumemu=0;Mix_VolumeMusic(volumemu);}
		else if(volum==1){afficher(volmu,screen);volumemu=10000;Mix_VolumeMusic(volumemu);}
		else if(volum==2){afficher(volmaxmu,screen);volumemu=20000;Mix_VolumeMusic(volumemu);}

	if (etat_settings==0 && etat_play==0 && checkf==0){
	     afficher(background1,screen);
	     afficher(emblem,screen);
	     if (played==0){afficher(play,screen);}
	     else {afficher(play1,screen);}
	     if (played1==0){afficher(cont,screen);}
	     else {afficher(cont1,screen);}
	     if (played2==0){afficher(settings,screen);}
	     else{afficher(settings1,screen);}
	     if (played3==0){afficher(quit,screen);}
	     else {afficher(quit1,screen);}
	     }
	SDL_Flip(screen);
//events
	while (SDL_PollEvent(&ev)){
		switch(ev.type){
			case SDL_MOUSEMOTION:
				mouseX=ev.motion.x;
				mouseY=ev.motion.y;
				if (mouseX >= play.pos1.x && mouseX < play.pos1.x + play.pos2.w && mouseY >= play.pos1.y && mouseY < play.pos1.y + play.pos2.h && etat_settings==0 && etat_play==0 && etat_continue==0)
				{
					if (played == 0) {
						channel=Mix_PlayChannel(-1, sonmotion, 0);
						played=1;
					}
				}
				else {
					if (played == 1) {
					played = 0;

					}
				}
				if (mouseX >= cont.pos1.x && mouseX < cont.pos1.x + cont.pos2.w && mouseY >= cont.pos1.y && mouseY < cont.pos1.y + cont.pos2.h && etat_settings==0 && etat_play==0 && etat_continue==0)
				{
					if (played1 == 0) {
						channel=Mix_PlayChannel(-1, sonmotion, 0);
						played1=1;
					}
				}
				else {
					if (played1 == 1) {
					played1 = 0;
					}
				}
				if (mouseX >= settings.pos1.x && mouseX < settings.pos1.x + settings.pos2.w && mouseY >= settings.pos1.y && mouseY < settings.pos1.y + play.pos2.h && etat_settings==0 && etat_play==0 && etat_continue==0)
				{
					if (played2 == 0) {
						channel=Mix_PlayChannel(-1, sonmotion, 0);
						played2=1;
						
					}
				}
				else {
					if (played2 == 1) {
					played2 = 0;
					}
				}
				if (mouseX >= quit.pos1.x && mouseX < quit.pos1.x + quit.pos2.w && mouseY >= quit.pos1.y && mouseY < quit.pos1.y + quit.pos2.h && etat_settings==0 && etat_play==0 && etat_continue==0)
				{
					if (played3 == 0) {
						channel=Mix_PlayChannel(-1, sonmotion, 0);
						played3=1;
					}
				}
				else {
					if (played3 == 1) {
					played3 = 0;
					}
				}
				if (mouseX >=save.pos1.x && mouseX < save.pos1.x + save.pos2.w && mouseY >= save.pos1.y && mouseY < save.pos1.y + save.pos2.h && etat_settings==1 )
				{
					if (played4 == 0) {
						channel=Mix_PlayChannel(-1, sonmotion, 0);
						played4=1;
					}
				}
				else {
					if (played4 == 1) {
					played4 = 0;
					}
				}
				if (mouseX >=cancel.pos1.x && mouseX < cancel.pos1.x + cancel.pos2.w && mouseY >= cancel.pos1.y && mouseY < cancel.pos1.y + cancel.pos2.h && etat_settings==1)
				{
					if (played5 == 0) {
						channel=Mix_PlayChannel(-1, sonmotion, 0);
						played5=1;
					}
				}
				else {
					if (played5 == 1) {
					played5 = 0;
					}
				}
			break;
			case SDL_MOUSEBUTTONDOWN:
				if((ev.button.x>=quit.pos1.x && ev.button.x<=quit.pos1.x+quit.pos2.w)&&(ev.button.y>=quit.pos1.y && ev.button.y<=quit.pos1.y+quit.pos2.h))
				{
					Mix_PlayChannel(1,sonclick,1);//jouer un son bref
					SDL_Flip(screen);
					run=0;
				}
				else if ((ev.button.x>=play.pos1.x && ev.button.x<=play.pos1.x+play.pos2.w)&&(ev.button.y>=play.pos1.y && ev.button.y<=play.pos1.y+play.pos2.h))
				{
					if(etat_play==0){
					channel=Mix_PlayChannel(1,sonclick,1);
					etat_play=1;}	
				}
				else if ((ev.button.x>=cont.pos1.x && ev.button.x<=cont.pos1.x+cont.pos2.w)&&(ev.button.y>=cont.pos1.y && ev.button.y<=cont.pos1.y+cont.pos2.h))
				{
					channel=Mix_PlayChannel(1,sonclick,1);

				}
				else if ((ev.button.x>=settings.pos1.x && ev.button.x<=settings.pos1.x+settings.pos2.w)&&(ev.button.y>=settings.pos1.y && ev.button.y<=settings.pos1.y+settings.pos2.h))
				{
					if(etat_play==0){
					channel=Mix_PlayChannel(1,sonclick,1);
					etat_settings=1;}
				}
				else if ((ev.button.x>=830 && ev.button.x<=860)&&(ev.button.y>=110 && ev.button.y<=140)&&etat_settings==1)
				{
					etat_settings=0;
				}
				else if ((ev.button.x>=checkfull.pos1.x && ev.button.x<=checkfull.pos1.x+checkfull.pos2.w)&&(ev.button.y>=checkfull.pos1.y && ev.button.y<=checkfull.pos1.y+checkfull.pos2.h) && etat_settings==1)
				{
					if(checkf==0){
					channel=Mix_PlayChannel(1,sonclick,1);
					checkf=1;}
					else
					    checkf=0;	
				}
				else if ((ev.button.x>=checkhemo.pos1.x && ev.button.x<=checkhemo.pos1.x+checkhemo.pos2.w)&&(ev.button.y>=checkhemo.pos1.y && ev.button.y<=checkhemo.pos1.y+checkhemo.pos2.h) && etat_settings==1)
				{
					if(checkh==0){
					channel=Mix_PlayChannel(1,sonclick,1);
					checkh=1;}
					else
					    checkh=0;	
				}
				else if ((ev.button.x>=468 && ev.button.x<=480)&&(ev.button.y>=204 && ev.button.y<=216) && etat_settings==1)
				{
					if(volu==1){channel=Mix_PlayChannel(1,sonclick,1);volu=0;}
					else if(volu==2){channel=Mix_PlayChannel(1,sonclick,1);volu=1;}		
				}
				else if ((ev.button.x>=572 && ev.button.x<=584)&&(ev.button.y>=204 && ev.button.y<=216) && etat_settings==1)
				{
					if(volu==0){channel=Mix_PlayChannel(1,sonclick,1);volu=1;}
					else if(volu==1){channel=Mix_PlayChannel(1,sonclick,1);volu=2;}		
				}
				else if ((ev.button.x>=468 && ev.button.x<=480)&&(ev.button.y>=240 && ev.button.y<=252) && etat_settings==1)
				{
					if(volum==1){channel=Mix_PlayChannel(1,sonclick,1);volum=0;}
					else if(volum==2){channel=Mix_PlayChannel(1,sonclick,1);volum=1;}		
				}
				else if ((ev.button.x>=572 && ev.button.x<=584)&&(ev.button.y>=240 && ev.button.y<=252) && etat_settings==1)
				{
					if(volum==0){channel=Mix_PlayChannel(1,sonclick,1);volum=1;}
					else if(volum==1){channel=Mix_PlayChannel(1,sonclick,1);volum=2;}		
				}
			break;
			case SDL_KEYDOWN:
					  if(ev.key.keysym.sym==SDLK_ESCAPE && etat_settings==1)
						etat_settings=0;
					  if(ev.key.keysym.sym==SDLK_ESCAPE && etat_play==1)
						etat_play=0;	
			break;
			case SDL_QUIT:
				run=0;
				break;
			
				
		}
	}
}
SDL_Quit();
return 0;
}
